<?php
session_start(); // Start the session

require 'db.php';

$userid = '555';


// Assuming $userid is defined somewhere before this code snippet


?>
