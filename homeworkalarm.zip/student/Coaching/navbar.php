
<nav class="navbar coaching-navbar">
<div><a href="editStudentProfile.php"><img src="../../img/person-circle.svg" class="profile-icon" alt="Profile Icon" height="40px" style="
    position: absolute;
    left: 2%;
    top: 12px;
    color: white;
"></a></div>
    <ul class="nav-list v-class-resp">
    <li><a href="editStudentProfile.php"><img src="../../img/person-circle.svg" class="profile-icon" alt="Profile Icon" height="40px" style="
    position: absolute;
    left: 2%;
    top: 12px;
    color: white;
"></a></li>
        <li><a href="index.php">Home</a></li>
        <li><a href="viewattendence.php">Attendence</a></li>
        <li><a href="studentFee.php">Payments</a></li>
        <li><a class="nav-link active" href="Announcement.php" role="button" aria-expanded="false">Announcement</a></li>
        <li class="nav-item dropdown">
          <a class="nav-link active" href="chat.php" role="button" aria-expanded="false">
            Chat
          </a>
        </li>
        <li><a class="nav-link active" href="logout.php" role="button" aria-expanded="false">Logout</a></li>
       </ul>
    <div class="burger" onclick="openBurger()">
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
    </div>
</nav>