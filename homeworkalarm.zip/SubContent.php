<link rel="stylesheet" href="css/SubConent.css">
<div class="sub-box SubConentBox">
        <div class="boxsub boxsub-1">
            <div class="topdivider-1 topdivider">
                <h2>Notification</h2>
            </div>
            <p><span class="icon-notification"><NotificationsIcon/></span>Lorem ipsum dolor sit amet consectetur </p>
            <hr />
            <p><span class="icon-notification"><NotificationsIcon/></span>Lorem ipsum dolor sit amet consectetur </p>
            <hr />
            <p><span class="icon-notification"><NotificationsIcon/></span>Lorem ipsum dolor sit amet consectetur </p>
            <hr />
            <p><span class="icon-notification"><NotificationsIcon/></span>Lorem ipsum dolor sit amet consectetur </p>
            <hr />
            <p><span class="icon-notification"><NotificationsIcon/></span>Lorem ipsum dolor sit amet consectetur </p>
            <hr />
        </div>
        <div class="boxsub boxsub-2">
            <div class="topdivider-2 topdivider">
                <h2>Events</h2>
            </div>
            <p><span class="icon-location"><NearMeRoundedIcon/></span>Lorem ipsum dolor sit amet consectetur </p>
            <hr />
            <p><span class="icon-location"><NearMeRoundedIcon/></span>Lorem ipsum dolor sit amet consectetur </p>
            <hr />
            <p><span class="icon-location"><NearMeRoundedIcon/></span>Lorem ipsum dolor sit amet consectetur </p>
            <hr />
            <p><span class="icon-location"><NearMeRoundedIcon/></span>Lorem ipsum dolor sit amet consectetur </p>
            <hr />
            <p><span class="icon-location"><NearMeRoundedIcon/></span>Lorem ipsum dolor sit amet consectetur </p>
            <hr />
        </div>
        <div class="boxsub boxsub-3">
            <div class="topdivider-3 topdivider">
                <h2>Blog/Artical</h2>
            </div>
            <p><span class="icon-date"><TagIcon/></span>Lorem ipsum dolor sit amet consectetur </p>
            <hr />
            <p><span class="icon-date"><TagIcon/></span>Lorem ipsum dolor sit amet consectetur </p>
            <hr />
            <p><span class="icon-date"><TagIcon/></span>Lorem ipsum dolor sit amet consectetur </p>
            <hr />
            <p><span class="icon-date"><TagIcon/></span>Lorem ipsum dolor sit amet consectetur </p>
            <hr />
            <p><span class="icon-date"><TagIcon/></span>Lorem ipsum dolor sit amet consectetur </p>
            <hr />
        </div>
      </div>