<?php

$server = "localhost";
$username = "u200853583_projectcoachin";
$password = "Lucky@Adarsh@1988";
$dbname = "u200853583_coaching";
// $server = "localhost";
// $username = "root";
// $password = "";
// $dbname = "acc";

$conn = new mysqli("$server", "$username","$password", "$dbname");  // Connect to

if(!$conn){
    echo 'Something Went Wrong';
}
?>