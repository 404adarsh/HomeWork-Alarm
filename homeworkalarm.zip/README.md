To Make Student Table - 

CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(255) NOT NULL,
    class VARCHAR(50) NOT NULL,
    father_name VARCHAR(255) NOT NULL,
    mother_name VARCHAR(255) NOT NULL,
    school VARCHAR(255) NOT NULL,
    subject VARCHAR(255) NOT NULL,
    aadhar_number VARCHAR(12) NOT NULL,
    phone_number VARCHAR(15) NOT NULL,
    alternate_number VARCHAR(15),
    address VARCHAR(255) NOT NULL,
    state VARCHAR(100) NOT NULL,
    city VARCHAR(100) NOT NULL,
    blood_group VARCHAR(5) NOT NULL,
    allergy VARCHAR(255),
    userid INT(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_by VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);





To Make Teachers Table-

CREATE TABLE teachers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    phone_number VARCHAR(15) NOT NULL,
    aadhar_number VARCHAR(12) NOT NULL,
    email VARCHAR(255) NOT NULL,
    class VARCHAR(50) NOT NULL,
    role VARCHAR(50) NOT NULL,
    teacher_id VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);



To Make Payments Table - 

CREATE TABLE payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    class VARCHAR(50) NOT NULL,
    student_name VARCHAR(255) NOT NULL,
    month VARCHAR(20) NOT NULL,
    subject VARCHAR(255) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    receiver VARCHAR(255) NOT NULL,
    payment_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


To Make Owner Table - 

CREATE TABLE owners (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone_number VARCHAR(15),
    date_of_birth DATE,
    name VARCHAR(255),
    age INT,
    gender ENUM('Male', 'Female', 'Other'),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


To Make Attendence Table - 

CREATE TABLE attendance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    userid INT NOT NULL,
    date DATE NOT NULL,
    present TINYINT(1) DEFAULT 0,
    CONSTRAINT fk_userid FOREIGN KEY (userid) REFERENCES students(userid),
    UNIQUE KEY unique_attendance (userid, date)
);


To Create Annoucement Table - 

CREATE TABLE announcement (
    sno INT AUTO_INCREMENT PRIMARY KEY,
    topic VARCHAR(255) NOT NULL,
    message_for VARCHAR(50) NOT NULL,
    message TEXT NOT NULL,
    highlight VARCHAR(255) NOT NULL,
    sent_by VARCHAR(255) NOT NULL,
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


To Create Chat Table - 

CREATE TABLE chat (
    sno INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    class VARCHAR(50),
    userid VARCHAR(50) NOT NULL,
    category VARCHAR(50),
    sendMessage TEXT,
    datetime TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);




