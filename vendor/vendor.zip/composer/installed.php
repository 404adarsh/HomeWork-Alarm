<?php return array(
    'root' => array(
        'name' => 'myusername/myproject',
        'pretty_version' => 'dev-main',
        'version' => 'dev-main',
        'reference' => '872373d0ef82bc1018c4b4864940f0326cd5e123',
        'type' => 'library',
        'install_path' => __DIR__ . '/../../',
        'aliases' => array(),
        'dev' => true,
    ),
    'versions' => array(
        'myusername/myproject' => array(
            'pretty_version' => 'dev-main',
            'version' => 'dev-main',
            'reference' => '872373d0ef82bc1018c4b4864940f0326cd5e123',
            'type' => 'library',
            'install_path' => __DIR__ . '/../../',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
    ),
);
